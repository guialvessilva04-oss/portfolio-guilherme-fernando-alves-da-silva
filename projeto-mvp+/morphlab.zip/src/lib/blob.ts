/**
 * Generates a smooth SVG path for a blob.
 * @param size The size of the square bounding box.
 * @param pointsCount The number of points (vertices) in the blob.
 * @param complexity Irregularity score (0 to 100).
 * @param seed Random seed for reproducibility.
 */
export function generateBlobPath(
  size: number,
  pointsCount: number,
  complexity: number,
  seed: number
): string {
  const center = size / 2;
  const radius = size * 0.35; // Base radius
  const points: { x: number; y: number }[] = [];
  const numPoints = Math.max(3, Math.floor(pointsCount));
  
  // Simple LCG for deterministic randomness based on seed
  const random = (s: number) => {
    const x = Math.sin(s) * 10000;
    return x - Math.floor(x);
  };

  const angleStep = (Math.PI * 2) / numPoints;
  const variation = complexity / 100;

  for (let i = 0; i < numPoints; i++) {
    const angle = i * angleStep;
    // We use seed + index to get unique random for each point
    const r = radius + (random(seed + i * 0.1) - 0.5) * radius * variation * 1.5;
    points.push({
      x: center + r * Math.cos(angle),
      y: center + r * Math.sin(angle),
    });
  }

  return createSmoothPath(points);
}

function createSmoothPath(points: { x: number; y: number }[]): string {
  if (points.length < 3) return "";

  const n = points.length;
  let path = `M ${points[0].x} ${points[0].y}`;

  for (let i = 0; i < n; i++) {
    const p0 = points[i === 0 ? n - 1 : i - 1];
    const p1 = points[i];
    const p2 = points[(i + 1) % n];
    const p3 = points[(i + 2) % n];

    // Catmull-Rom to Cubic Bezier conversion
    // cp1 = p1 + (p2 - p0) / 6
    // cp2 = p2 - (p3 - p1) / 6
    
    const cp1x = p1.x + (p2.x - p0.x) / 6;
    const cp1y = p1.y + (p2.y - p0.y) / 6;
    
    const cp2x = p2.x - (p3.x - p1.x) / 6;
    const cp2y = p2.y - (p3.y - p1.y) / 6;

    path += ` C ${cp1x} ${cp1y}, ${cp2x} ${cp2y}, ${p2.x} ${p2.y}`;
  }

  path += " Z";
  return path;
}
