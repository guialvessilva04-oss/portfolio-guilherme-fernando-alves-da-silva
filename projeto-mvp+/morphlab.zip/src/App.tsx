import { useState, useCallback, useEffect, useRef, useMemo, FormEvent } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  RefreshCw, 
  Download, 
  Copy, 
  Check, 
  RotateCcw, 
  RotateCw, 
  Dice5,
  Code,
  Eye,
  ChevronDown,
  Github,
  User as UserIcon,
  Settings,
  Accessibility as AccessibilityIcon,
  LogOut,
  LogIn,
  UserPlus,
  Type,
  Wind,
  Plus,
  Palette,
  Mail,
  Chrome,
  Languages
} from "lucide-react";
import confetti from "canvas-confetti";
import { HexColorPicker, HexColorInput } from "react-colorful";
import { generateBlobPath } from "@/src/lib/blob";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { 
  Tooltip, 
  TooltipContent, 
  TooltipProvider, 
  TooltipTrigger 
} from "@/components/ui/tooltip";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import { auth, db } from "./lib/firebase";
import { 
  signInWithPopup, 
  GoogleAuthProvider, 
  onAuthStateChanged, 
  signOut,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  User
} from "firebase/auth";
import { doc, setDoc, getDoc } from "firebase/firestore";

const PRESETS = [
  { name: "Cloud", points: 8, complexity: 15, color: "#60A5FA", animate: true, motionType: "float" as const, motionSpeed: 3 },
  { name: "Ink", points: 12, complexity: 85, color: "#1F2937", animate: false, motionType: "breathe" as const, motionSpeed: 5 },
  { name: "Bacteria", points: 20, complexity: 60, color: "#10B981", animate: true, motionType: "breathe" as const, motionSpeed: 8 },
  { name: "Organic", points: 6, complexity: 40, color: "#F59E0B", animate: false, motionType: "breathe" as const, motionSpeed: 5 },
  { name: "Soft", points: 4, complexity: 10, color: "#EEF2FF", animate: true, motionType: "pulse" as const, motionSpeed: 2 },
  { name: "Volcano", points: 15, complexity: 75, color: "#EF4444", animate: true, motionType: "spin" as const, motionSpeed: 4 },
];

const COLOR_PRESETS = [
  "#FF006E", "#8338EC", "#3A86FF", "#FB5607", "#FFBE0B",
  "#06D6A0", "#118AB2", "#073B4C", "#EF476F", "#FFD166"
];

const LANGUAGES = {
  en: {
    properties: "Properties",
    shape: "Shape",
    style: "Style",
    complexity: "Complexity",
    points: "Points",
    blur: "Blur",
    breathe: "Breathe Animation",
    organic: "Organic movement effect",
    colorMode: "Color Mode",
    solid: "Solid",
    gradient: "Gradient",
    color1: "Color 1",
    color2: "Color 2",
    angle: "Angle",
    random: "Random",
    save: "Save to Account",
    loginToSave: "Login to Save",
    export: "Export",
    quickPresets: "Quick Presets",
    accessibility: "Accessibility Settings",
    highContrast: "High Contrast",
    uiScale: "UI Scale",
    visionFilters: "Vision Filters",
    signIn: "Sign In",
    createAccount: "Create Account",
    logout: "Sign Out",
    language: "Language",
    inspired: "Inspired by",
    madeWith: "Made with",
    login: "Login",
    signup: "Sign Up",
    share: "Share",
    preview: "Preview",
    code: "Code",
    motion: "Motion",
    motionType: "Motion Type",
    motionSpeed: "Motion Speed",
    typeBreathe: "Breathe",
    typeSpin: "Spin",
    typePulse: "Pulse",
    typeFloat: "Float",
    typeElastic: "Elastic",
    complexityDesc: "Controls the organic randomness and vertex distance from center.",
    pointsDesc: "Minimum points create smoother curves, higher points create complexity.",
    visionDesc: "Filters apply only to the blob preview."
  },
  pt: {
    properties: "Propriedades",
    shape: "Forma",
    style: "Estilo",
    complexity: "Complexidade",
    points: "Pontos",
    blur: "Desfoque",
    breathe: "Animação de Respiração",
    organic: "Movimento orgânico",
    colorMode: "Modo de Cor",
    solid: "Sólido",
    gradient: "Gradiente",
    color1: "Cor 1",
    color2: "Cor 2",
    angle: "Ângulo",
    random: "Aleatório",
    save: "Salvar na Conta",
    loginToSave: "Login p/ Salvar",
    export: "Exportar",
    quickPresets: "Presets Rápidos",
    accessibility: "Acessibilidade",
    highContrast: "Alto Contraste",
    uiScale: "Escala da UI",
    visionFilters: "Filtros de Visão",
    signIn: "Entrar",
    createAccount: "Criar Conta",
    logout: "Sair",
    language: "Idioma",
    inspired: "Inspirado por",
    madeWith: "Feito com",
    login: "Entrar",
    signup: "Cadastro",
    share: "Compartilhar",
    preview: "Visualizar",
    code: "Código",
    motion: "Movimento",
    motionType: "Tipo de Movimento",
    motionSpeed: "Velocidade",
    typeBreathe: "Respirar",
    typeSpin: "Girar",
    typePulse: "Pulsar",
    typeFloat: "Flutuar",
    typeElastic: "Elástico",
    complexityDesc: "Controla a aleatoriedade e distância dos vértices.",
    pointsDesc: "Poucos pontos criam curvas suaves, muitos criam complexidade.",
    visionDesc: "Filtros afetam apenas o preview do blob."
  },
  es: {
    properties: "Propiedades",
    shape: "Forma",
    style: "Estilo",
    complexity: "Complejidad",
    points: "Puntos",
    blur: "Desenfoque",
    breathe: "Animación de Respiro",
    organic: "Efecto de movimiento",
    colorMode: "Modo de Color",
    solid: "Sólido",
    gradient: "Degradado",
    color1: "Color 1",
    color2: "Color 2",
    angle: "Ángulo",
    random: "Aleatorio",
    save: "Guardar en Cuenta",
    loginToSave: "Login p/ Guardar",
    export: "Exportar",
    quickPresets: "Ajustes Rápidos",
    accessibility: "Accesibilidad",
    highContrast: "Alto Contraste",
    uiScale: "Escala de UI",
    visionFilters: "Filtros de Visión",
    signIn: "Entrar",
    createAccount: "Crear Cuenta",
    logout: "Cerrar Sesión",
    language: "Idioma",
    inspired: "Inspirado por",
    madeWith: "Hecho con",
    login: "Entrar",
    signup: "Registro",
    share: "Compartir",
    preview: "Vista Previa",
    code: "Código",
    motion: "Movimiento",
    motionType: "Tipo de Movimiento",
    motionSpeed: "Velocidad",
    typeBreathe: "Respirar",
    typeSpin: "Girar",
    typePulse: "Pulsar",
    typeFloat: "Flotar",
    typeElastic: "Elástico",
    complexityDesc: "Controla la aleatoriedad orgánica y distancia de vértices.",
    pointsDesc: "Menos puntos crean curvas suaves, más puntos crean complejidad.",
    visionDesc: "Los filtros solo se aplican a la vista previa."
  }
};

interface AppState {
  points: number;
  complexity: number;
  blur: number;
  seed: number;
  color1: string;
  color2: string;
  gradient: boolean;
  angle: number;
  animate: boolean;
  motionType: "breathe" | "spin" | "pulse" | "float" | "elastic";
  motionSpeed: number;
  // Accessibility
  highContrast: boolean;
  visionFilter: "none" | "protanopia" | "deuteranopia" | "tritanopia";
  uiScale: number;
  language: "en" | "pt" | "es";
}

export default function App() {
  const [state, setState] = useState<AppState>({
    points: 8,
    complexity: 40,
    blur: 0,
    seed: Math.floor(Math.random() * 100000),
    color1: "#FF006E",
    color2: "#FFBE0B",
    gradient: false,
    angle: 45,
    animate: false,
    motionType: "breathe",
    motionSpeed: 5,
    highContrast: false,
    visionFilter: "none",
    uiScale: 1,
    language: "pt",
  });

  const t = LANGUAGES[state.language];

  const [history, setHistory] = useState<AppState[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [previewMode, setPreviewMode] = useState<"blob" | "code">("blob");
  const [copied, setCopied] = useState(false);
  const svgRef = useRef<SVGSVGElement>(null);

  // Firebase Auth State
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [authError, setAuthError] = useState<string | null>(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isAuthDialogOpen, setIsAuthDialogOpen] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setCurrentUser(user);
      setAuthLoading(false);
      if (user) {
        setIsAuthDialogOpen(false);
      }
    });
    return () => unsubscribe();
  }, []);

  const handleGoogleSignIn = async () => {
    setAuthLoading(true);
    setAuthError(null);
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
    } catch (error: any) {
      setAuthError(error.message);
    } finally {
      setAuthLoading(false);
    }
  };

  const handleEmailSignUp = async (e: FormEvent) => {
    e.preventDefault();
    setAuthLoading(true);
    setAuthError(null);
    try {
      await createUserWithEmailAndPassword(auth, email, password);
    } catch (error: any) {
      setAuthError(error.message);
    } finally {
      setAuthLoading(false);
    }
  };

  const handleEmailLogin = async (e: FormEvent) => {
    e.preventDefault();
    setAuthLoading(true);
    setAuthError(null);
    try {
      await signInWithEmailAndPassword(auth, email, password);
    } catch (error: any) {
      setAuthError(error.message);
    } finally {
      setAuthLoading(false);
    }
  };

  const handleLogout = async () => {
    await signOut(auth);
  };

  const currentPath = useMemo(() => {
    return generateBlobPath(600, state.points, state.complexity, state.seed);
  }, [state.points, state.complexity, state.seed]);

  const animatedPath = useMemo(() => {
    if (!state.animate) return null;
    return generateBlobPath(600, state.points, state.complexity, state.seed + 100);
  }, [state.animate, state.points, state.complexity, state.seed]);

  const animatedPath2 = useMemo(() => {
    if (!state.animate) return null;
    return generateBlobPath(600, state.points, state.complexity, state.seed + 200);
  }, [state.animate, state.points, state.complexity, state.seed]);

  // History management
  const updateState = useCallback((newState: Partial<AppState>, pushHistory = true) => {
    setState(prev => {
      const next = { ...prev, ...newState };
      if (pushHistory) {
        const newHistory = history.slice(0, historyIndex + 1);
        newHistory.push(next);
        if (newHistory.length > 50) newHistory.shift();
        setHistory(newHistory);
        setHistoryIndex(newHistory.length - 1);
      }
      return next;
    });
  }, [history, historyIndex]);

  useEffect(() => {
    if (history.length === 0) {
      setHistory([state]);
      setHistoryIndex(0);
    }
  }, []);

  const undo = () => {
    if (historyIndex > 0) {
      const prev = history[historyIndex - 1];
      setState(prev);
      setHistoryIndex(historyIndex - 1);
    }
  };

  const redo = () => {
    if (historyIndex < history.length - 1) {
      const next = history[historyIndex + 1];
      setState(next);
      setHistoryIndex(historyIndex + 1);
    }
  };

  const randomize = () => {
    updateState({ seed: Math.floor(Math.random() * 100000) });
  };

  const [saving, setSaving] = useState(false);
  const saveBlob = async () => {
    if (!currentUser) {
      setIsAuthDialogOpen(true);
      return;
    }
    setSaving(true);
    try {
      const blobRef = doc(db, "users", currentUser.uid, "saved_blobs", `blob-${state.seed}`);
      await setDoc(blobRef, {
        ...state,
        createdAt: new Date().toISOString(),
      });
      confetti({
        particleCount: 150,
        spread: 90,
        origin: { y: 0.5 },
        colors: [state.color1, state.color2]
      });
    } catch (error: any) {
      console.error("Error saving blob:", error);
    } finally {
      setSaving(false);
    }
  };

  const visionFilters = {
    none: "",
    protanopia: "url(#protanopia)",
    deuteranopia: "url(#deuteranopia)",
    tritanopia: "url(#tritanopia)",
  };

  const applyPreset = (preset: typeof PRESETS[0]) => {
    updateState({
      points: preset.points,
      complexity: preset.complexity,
      color1: preset.color,
      animate: preset.animate,
      motionType: preset.motionType,
      motionSpeed: preset.motionSpeed,
      gradient: false,
    });
  };

  const fullSvgString = useMemo(() => {
    const fill = state.gradient 
      ? "url(#grad)" 
      : state.color1;
    
    return `<svg viewBox="0 0 600 600" xmlns="http://www.w3.org/2000/svg">
  ${state.gradient ? `
  <defs>
    <linearGradient id="grad" gradientTransform="rotate(${state.angle})">
      <stop offset="0%" stop-color="${state.color1}" />
      <stop offset="100%" stop-color="${state.color2}" />
    </linearGradient>
  </defs>` : ""}
  <filter id="blur">
    <feGaussianBlur in="SourceGraphic" stdDeviation="${state.blur}" />
  </filter>
  <path fill="${fill}" d="${currentPath}" filter="url(#blur)"/>
</svg>`;
  }, [state, currentPath]);

  const copyToClipboard = async (text: string, type: "svg" | "css") => {
    await navigator.clipboard.writeText(text);
    setCopied(true);
    if (type === "svg") {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
        colors: [state.color1, state.color2]
      });
    }
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadFile = (format: "svg" | "png") => {
    if (format === "svg") {
      const blob = new Blob([fullSvgString], { type: "image/svg+xml" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `blob-${state.seed}.svg`;
      link.click();
    } else {
      // PNG Export using Canvas
      const canvas = document.createElement("canvas");
      canvas.width = 1200;
      canvas.height = 1200;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;

      const img = new Image();
      const svgBlob = new Blob([fullSvgString], { type: "image/svg+xml;charset=utf-8" });
      const url = URL.createObjectURL(svgBlob);

      img.onload = () => {
        ctx.drawImage(img, 0, 0, 1200, 1200);
        const pngUrl = canvas.toDataURL("image/png");
        const link = document.createElement("a");
        link.href = pngUrl;
        link.download = `blob-${state.seed}.png`;
        link.click();
        URL.revokeObjectURL(url);
      };
      img.src = url;
    }
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: "Check out this blob I made!",
          text: "I generated this cool organic shape using MorphLab.",
          url: window.location.href,
        });
      } catch (err) {
        copyToClipboard(window.location.href, "css");
      }
    } else {
      copyToClipboard(window.location.href, "css");
    }
  };

  return (
    <TooltipProvider>
      <div 
        className={cn(
          "min-h-screen bg-background text-foreground font-sans selection:bg-primary/20 transition-all duration-300",
          state.highContrast && "contrast-[1.25] saturate-[1.2]",
        )}
        style={{ fontSize: `${state.uiScale * 100}%` }}
      >
        
        {/* Navigation / Header */}
        <header className="fixed top-0 left-0 right-0 h-16 border-b border-white/5 bg-background/50 backdrop-blur-md z-50 flex items-center justify-between px-6">
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center">
              <svg viewBox="0 0 100 100" className="w-9 h-9 select-none overflow-visible">
                <defs>
                  <linearGradient id="morph-logo-grad" x1="0%" y1="100%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#FF006E" />
                    <stop offset="40%" stopColor="#8338EC" />
                    <stop offset="100%" stopColor="#3A86FF" />
                  </linearGradient>
                  <filter id="logo-glow" x="-50%" y="-50%" width="200%" height="200%">
                    <feGaussianBlur stdDeviation="4" result="blur" />
                    <feComposite in="SourceGraphic" in2="blur" operator="over" />
                  </filter>
                </defs>
                <motion.path
                  d="M20,80 C20,20 45,20 50,60 C55,20 80,20 80,80"
                  fill="none"
                  stroke="url(#morph-logo-grad)"
                  strokeWidth="16"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  filter="url(#logo-glow)"
                  animate={{
                    d: [
                      "M20,80 C20,20 45,20 50,60 C55,20 80,20 80,80",
                      "M22,75 C25,25 45,25 50,65 C55,25 75,25 78,75",
                      "M20,85 C15,15 45,15 50,55 C55,15 85,15 80,85",
                      "M20,80 C20,20 45,20 50,60 C55,20 80,20 80,80"
                    ]
                  }}
                  transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
                />
              </svg>
            </div>
            <h1 className="font-bold tracking-tight text-xl font-display">Morph<span className="text-primary">Lab</span></h1>
          </div>
          
          <div className="flex items-center gap-2">
            <DropdownMenu>
              <DropdownMenuTrigger
                render={<Button variant="ghost" size="icon" className="rounded-full" title={t.language} />}
              >
                <Languages className="w-5 h-5" />
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="bg-card border-white/10 w-[120px]">
                {(Object.keys(LANGUAGES) as Array<keyof typeof LANGUAGES>).map((lang) => (
                  <DropdownMenuItem 
                    key={lang} 
                    onClick={() => updateState({ language: lang }, false)}
                    className={cn("capitalize", state.language === lang && "bg-primary/20 font-bold")}
                  >
                    {lang === 'en' ? 'English' : lang === 'pt' ? 'Português' : 'Español'}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            <Dialog>
              <DialogTrigger
                render={<Button variant="ghost" size="icon" className="rounded-full" title={t.accessibility} />}
              >
                <AccessibilityIcon className="w-5 h-5" />
              </DialogTrigger>
              <DialogContent className="sm:max-w-[425px] bg-card border-white/10 text-foreground">
                <DialogHeader>
                  <DialogTitle className="font-display text-xl">{t.accessibility}</DialogTitle>
                  <DialogDescription>
                    Customize your visual experience for better accessibility.
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-6 py-4">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="high-contrast" className="font-bold">{t.highContrast}</Label>
                    <Switch 
                      id="high-contrast"
                      checked={state.highContrast} 
                      onCheckedChange={(v) => updateState({ highContrast: v }, false)} 
                    />
                  </div>
                  
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <Type className="w-4 h-4 opacity-50" />
                      <Label className="font-bold">{t.uiScale}</Label>
                    </div>
                    <Slider 
                      value={[state.uiScale]} 
                      onValueChange={(v) => updateState({ uiScale: Array.isArray(v) ? v[0] : v }, false)} 
                      min={0.8} 
                      max={1.5} 
                      step={0.05} 
                    />
                    <p className="text-[10px] opacity-50">Adjust the base font size and interface scaling.</p>
                  </div>

                  <div className="space-y-3">
                    <Label className="font-bold">{t.visionFilters}</Label>
                    <div className="grid grid-cols-2 gap-2">
                      {["none", "protanopia", "deuteranopia", "tritanopia"].map((filter) => (
                        <Button
                          key={filter}
                          variant={state.visionFilter === filter ? "secondary" : "outline"}
                          size="sm"
                          className="capitalize text-xs rounded-xl"
                          onClick={() => updateState({ visionFilter: filter as any }, false)}
                        >
                          {filter}
                        </Button>
                      ))}
                    </div>
                    <p className="text-[10px] opacity-50 italic">{t.visionDesc}</p>
                  </div>
                </div>
              </DialogContent>
            </Dialog>

            {currentUser ? (
              <DropdownMenu>
                <DropdownMenuTrigger
                  render={
                    <Button variant="ghost" size="icon" className="rounded-full overflow-hidden border border-white/10" title="Account" />
                  }
                >
                  {currentUser.photoURL ? (
                    <img src={currentUser.photoURL} alt="User" className="w-full h-full object-cover" referrerpolicy="no-referrer" />
                  ) : (
                    <UserIcon className="w-5 h-5" />
                  )}
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-[200px] bg-card border-white/10 text-foreground">
                  <div className="p-3 border-b border-white/5 mb-1">
                    <p className="text-sm font-bold truncate font-display">{currentUser.displayName || currentUser.email}</p>
                    <p className="text-[10px] opacity-50 truncate">{currentUser.email}</p>
                  </div>
                  <DropdownMenuItem onClick={handleLogout} className="gap-2 focus:bg-destructive/10 focus:text-destructive text-destructive">
                    <LogOut className="w-4 h-4" /> {t.logout}
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Dialog open={isAuthDialogOpen} onOpenChange={setIsAuthDialogOpen}>
                <DialogTrigger render={<Button variant="ghost" size="icon" className="rounded-full" title="Account" />}>
                  <UserIcon className="w-5 h-5" />
                </DialogTrigger>
                <DialogContent className="sm:max-w-[400px] bg-card border-white/10 text-foreground">
                  <Tabs defaultValue="login" className="w-full">
                    <DialogHeader className="mb-4">
                      <TabsList className="grid w-full grid-cols-2">
                        <TabsTrigger value="login" className="font-display">{t.login}</TabsTrigger>
                        <TabsTrigger value="signup" className="font-display">{t.signup}</TabsTrigger>
                      </TabsList>
                      {authError && (
                        <p className="text-xs text-destructive bg-destructive/10 p-2 rounded mt-2">{authError}</p>
                      )}
                    </DialogHeader>
                    
                    <TabsContent value="login" className="space-y-4 pt-2">
                      <form onSubmit={handleEmailLogin} className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="login-email">Email</Label>
                          <Input 
                            id="login-email" 
                            type="email" 
                            placeholder="email@example.com" 
                            className="bg-muted border-white/5 rounded-xl" 
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="login-password">Password</Label>
                          <Input 
                            id="login-password" 
                            type="password" 
                            className="bg-muted border-white/5 rounded-xl" 
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            required
                          />
                        </div>
                        <Button type="submit" className="w-full bg-[#FF006E] hover:bg-[#D4005B] text-white rounded-xl h-11" disabled={authLoading}>
                          {authLoading ? "..." : t.signIn}
                        </Button>
                      </form>
                      <div className="relative py-4">
                        <div className="absolute inset-0 flex items-center"><span className="w-full border-t border-white/5" /></div>
                        <div className="relative flex justify-center text-xs uppercase"><span className="bg-card px-2 text-muted-foreground">Or</span></div>
                      </div>
                      <Button variant="outline" className="w-full gap-2 border-white/10 rounded-xl" onClick={handleGoogleSignIn} disabled={authLoading}>
                        <Chrome className="w-4 h-4" /> Google
                      </Button>
                    </TabsContent>

                    <TabsContent value="signup" className="space-y-4 pt-2">
                      <form onSubmit={handleEmailSignUp} className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="signup-email">Email</Label>
                          <Input 
                            id="signup-email" 
                            type="email" 
                            placeholder="email@example.com" 
                            className="bg-muted border-white/5 rounded-xl" 
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="signup-password">Password</Label>
                          <Input 
                            id="signup-password" 
                            type="password" 
                            className="bg-muted border-white/5 rounded-xl" 
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            required
                          />
                        </div>
                        <Button type="submit" className="w-full bg-[#FF006E] hover:bg-[#D4005B] text-white rounded-xl h-11" disabled={authLoading}>
                          {authLoading ? "..." : t.createAccount}
                        </Button>
                      </form>
                    </TabsContent>
                  </Tabs>
                </DialogContent>
              </Dialog>
            )}

            <Button variant="ghost" size="sm" onClick={handleShare} className="hidden sm:flex gap-2 rounded-full">
              <Copy className="w-4 h-4" />
              <span>{t.share}</span>
            </Button>
          </div>
        </header>

        {/* Main Content Area */}
        <main className="pt-16 pb-32 md:pb-0 h-screen flex flex-col md:flex-row overflow-hidden font-sans">
          
          {/* Left Side: Preview area */}
          <div className="flex-1 relative flex items-center justify-center p-8 bg-[#18181b] overflow-hidden">
            <div className="absolute inset-0 pointer-events-none">
              <div className="absolute inset-0 bg-grid-white/5 opacity-10" />
            </div>

            <div className="absolute top-6 left-6 flex gap-2 z-10">
              <div className="bg-white/5 border border-white/10 rounded-full px-4 py-2 text-xs font-mono flex items-center gap-2 shadow-xl backdrop-blur-2xl">
                <span className="opacity-40 text-white">SEED:</span>
                <input 
                  type="number" 
                  value={state.seed} 
                  onChange={(e) => updateState({ seed: parseInt(e.target.value) || 0 })}
                  className="bg-transparent border-none outline-none w-20 text-white font-bold"
                />
              </div>
            </div>

            <div className="absolute top-6 right-6 flex gap-2 z-10">
              <div className="flex p-1 bg-white/5 border border-white/10 rounded-full shadow-xl backdrop-blur-2xl">
                <Button 
                  variant={previewMode === "blob" ? "secondary" : "ghost"} 
                  size="sm" 
                  onClick={() => setPreviewMode("blob")}
                  className={cn("rounded-full px-4 h-8 text-xs gap-2 font-display transition-all", previewMode === "blob" ? "bg-white text-black shadow-lg" : "text-white hover:bg-white/10")}
                >
                  <Eye className="w-3.5 h-3.5" /> {t.preview}
                </Button>
                <Button 
                  variant={previewMode === "code" ? "secondary" : "ghost"} 
                  size="sm" 
                  onClick={() => setPreviewMode("code")}
                  className={cn("rounded-full px-4 h-8 text-xs gap-2 font-display transition-all", previewMode === "code" ? "bg-white text-black shadow-lg" : "text-white hover:bg-white/10")}
                >
                  <Code className="w-3.5 h-3.5" /> {t.code}
                </Button>
              </div>
            </div>

            <AnimatePresence mode="wait">
              {previewMode === "blob" ? (
                <div key="blob" className="relative w-full max-w-lg aspect-square">
                  <motion.svg
                    ref={svgRef}
                    viewBox="0 0 600 600"
                    className="w-full h-full filter drop-shadow-[0_25px_50px_rgba(0,0,0,0.5)]"
                    initial={{ scale: 0.8, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 1.1, opacity: 0 }}
                  >
                    {state.gradient && (
                      <defs>
                        <linearGradient id="blob-grad" x1="0%" y1="0%" x2="100%" y2="100%" gradientTransform={`rotate(${state.angle})`}>
                          <stop offset="0%" stopColor={state.color1} />
                          <stop offset="100%" stopColor={state.color2} />
                        </linearGradient>
                      </defs>
                    )}
                    <filter id="blob-blur" x="-50%" y="-50%" width="200%" height="200%">
                      <feGaussianBlur in="SourceGraphic" stdDeviation={state.blur} result="blur" />
                      <feMerge>
                        <feMergeNode in="blur" />
                        <feMergeNode in="SourceGraphic" />
                      </feMerge>
                    </filter>
                    
                    {/* Vision Deficiency Filters */}
                    <filter id="protanopia">
                      <feColorMatrix type="matrix" values="0.567, 0.433, 0, 0, 0, 0.558, 0.442, 0, 0, 0, 0, 0.242, 0.758, 0, 0, 0, 0, 0, 1, 0" />
                    </filter>
                    <filter id="deuteranopia">
                      <feColorMatrix type="matrix" values="0.625, 0.375, 0, 0, 0, 0.7, 0.3, 0, 0, 0, 0, 0.3, 0.7, 0, 0, 0, 0, 0, 1, 0" />
                    </filter>
                    <filter id="tritanopia">
                      <feColorMatrix type="matrix" values="0.95, 0.05, 0, 0, 0, 0, 0.433, 0.567, 0, 0, 0, 0.475, 0.525, 0, 0, 0, 0, 0, 1, 0" />
                    </filter>

                    <motion.path
                      fill={state.gradient ? "url(#blob-grad)" : state.color1}
                      filter={state.blur > 0 ? "url(#blob-blur)" : visionFilters[state.visionFilter]}
                      style={{ 
                        filter: state.blur > 0 ? `url(#blob-blur) ${visionFilters[state.visionFilter]}` : visionFilters[state.visionFilter],
                        transformOrigin: "300px 300px"
                      }}
                      animate={{ 
                        d: state.animate && animatedPath && animatedPath2
                          ? [currentPath, animatedPath, animatedPath2, currentPath] 
                          : currentPath,
                        rotate: state.animate && state.motionType === "spin" ? [0, 360] : 0,
                        scale: state.animate && state.motionType === "pulse" 
                          ? [1, 1.15, 1] 
                          : state.animate && state.motionType === "breathe"
                          ? [1, 1.05, 1]
                          : state.animate && state.motionType === "elastic"
                          ? [1, 0.9, 1.1, 1]
                          : 1,
                        x: state.animate && state.motionType === "float" ? [0, 15, -15, 0] : 0,
                        y: state.animate && state.motionType === "float" ? [0, -10, 10, 0] : 0,
                      }}
                      transition={{ 
                        d: { 
                          duration: state.animate 
                            ? (state.motionType === "pulse" ? 2 : state.motionType === "spin" ? 8 : state.motionType === "elastic" ? 1.5 : 6) * (11 - state.motionSpeed) / 5
                            : 0.5, 
                          ease: state.motionType === "elastic" ? "backInOut" : "easeInOut", 
                          repeat: state.animate ? Infinity : 0 
                        },
                        rotate: { 
                          duration: (11 - state.motionSpeed) * 2, 
                          ease: "linear", 
                          repeat: Infinity 
                        },
                        scale: { 
                          duration: (11 - state.motionSpeed) * (state.motionType === "pulse" ? 1.5 : 2), 
                          ease: "easeInOut", 
                          repeat: Infinity 
                        },
                        x: { 
                          duration: (11 - state.motionSpeed) * 2, 
                          ease: "easeInOut", 
                          repeat: Infinity 
                        },
                        y: { 
                          duration: (11 - state.motionSpeed) * 2, 
                          ease: "easeInOut", 
                          repeat: Infinity,
                          delay: 0.5
                        }
                      }}
                    />
                  </motion.svg>
                </div>
              ) : (
                <motion.div 
                  key="code"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="w-full max-w-2xl bg-zinc-900 rounded-2xl p-6 font-mono text-sm text-zinc-300 shadow-2xl relative group"
                >
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="absolute top-4 right-4 text-zinc-400 hover:text-white"
                    onClick={() => copyToClipboard(fullSvgString, "svg")}
                  >
                    {copied ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
                  </Button>
                  <pre className="overflow-auto max-h-[400px] scrollbar-hide">
                    <code>{fullSvgString}</code>
                  </pre>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Right Side: Controls Panel */}
          <aside className="w-full md:w-[400px] border-l border-white/5 bg-[#1a1a1a]/95 backdrop-blur-3xl p-6 flex flex-col gap-6 overflow-y-auto z-40 relative">
            <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
            
            <div className="flex items-center justify-between mb-2">
              <h2 className="font-bold text-xl font-display">{t.properties}</h2>
              <div className="flex gap-1">
                <Button variant="ghost" size="icon" onClick={undo} disabled={historyIndex <= 0} title="Undo">
                  <RotateCcw className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="icon" onClick={redo} disabled={historyIndex >= history.length - 1} title="Redo">
                  <RotateCw className="w-4 h-4" />
                </Button>
              </div>
            </div>

            <Tabs defaultValue="shape" className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-6">
                <TabsTrigger value="shape" className="font-display">{t.shape}</TabsTrigger>
                <TabsTrigger value="style" className="font-display">{t.style}</TabsTrigger>
              </TabsList>
              
              <TabsContent value="shape" className="space-y-8 mt-0">
                <div className="space-y-4">
                  <div className="flex justify-between items-baseline mb-2">
                    <Label className="text-sm font-medium opacity-60">{t.complexity}</Label>
                    <span className="font-mono text-xs font-bold text-primary">{state.complexity}</span>
                  </div>
                  <Slider 
                    value={[state.complexity]} 
                    onValueChange={(v) => updateState({ complexity: Array.isArray(v) ? v[0] : v })} 
                    max={100} 
                    step={1} 
                  />
                  <p className="text-[10px] opacity-40 leading-tight">{t.complexityDesc}</p>
                </div>

                <div className="space-y-4">
                  <div className="flex justify-between items-baseline mb-2">
                    <Label className="text-sm font-medium opacity-60">{t.points}</Label>
                    <span className="font-mono text-xs font-bold text-primary">{state.points}</span>
                  </div>
                  <Slider 
                    value={[state.points]} 
                    onValueChange={(v) => updateState({ points: Array.isArray(v) ? v[0] : v })} 
                    min={3} 
                    max={20} 
                    step={1} 
                  />
                  <p className="text-[10px] opacity-40 leading-tight">{t.pointsDesc}</p>
                </div>

                <div className="space-y-4">
                  <div className="flex justify-between items-baseline mb-2">
                    <Label className="text-sm font-medium opacity-60">{t.blur}</Label>
                    <span className="font-mono text-xs font-bold text-primary">{state.blur}px</span>
                  </div>
                  <Slider 
                    value={[state.blur]} 
                    onValueChange={(v) => updateState({ blur: Array.isArray(v) ? v[0] : v })} 
                    max={50} 
                    step={1} 
                  />
                </div>

                <div className="space-y-6 pt-4 border-t border-white/5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className={cn("p-2 rounded-lg transition-colors", state.animate ? "bg-primary text-white" : "bg-zinc-200 dark:bg-zinc-700")}>
                        <Wind className="w-4 h-4" />
                      </div>
                      <div>
                        <p className="text-sm font-bold font-display">{t.motion}</p>
                        <p className="text-[10px] opacity-50">{t.organic}</p>
                      </div>
                    </div>
                    <Switch 
                      checked={state.animate} 
                      onCheckedChange={(v) => updateState({ animate: v })} 
                    />
                  </div>

                  {state.animate && (
                    <motion.div 
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      className="space-y-6 overflow-hidden"
                    >
                      <div className="space-y-3">
                        <Label className="text-[10px] font-bold uppercase tracking-wider opacity-40">{t.motionType}</Label>
                        <div className="grid grid-cols-2 gap-2">
                          {(["breathe", "spin", "pulse", "float", "elastic"] as const).map((m) => (
                            <Button
                              key={m}
                              variant={state.motionType === m ? "secondary" : "outline"}
                              size="sm"
                              className="text-xs h-9 rounded-xl font-display"
                              onClick={() => updateState({ motionType: m })}
                            >
                              {m === "breathe" ? t.typeBreathe : m === "spin" ? t.typeSpin : m === "pulse" ? t.typePulse : m === "float" ? t.typeFloat : t.typeElastic}
                            </Button>
                          ))}
                        </div>
                      </div>

                      <div className="space-y-3">
                        <div className="flex justify-between items-baseline mb-2">
                          <Label className="text-xs font-bold uppercase tracking-wider opacity-40">{t.motionSpeed}</Label>
                          <span className="font-mono text-xs font-bold text-primary">{state.motionSpeed}</span>
                        </div>
                        <Slider 
                          value={[state.motionSpeed]} 
                          onValueChange={(v) => updateState({ motionSpeed: Array.isArray(v) ? v[0] : v })} 
                          min={1} 
                          max={10} 
                          step={1} 
                        />
                      </div>
                    </motion.div>
                  )}
                </div>
              </TabsContent>

              <TabsContent value="style" className="space-y-8 mt-0">
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <Label className="font-bold">{t.colorMode}</Label>
                    <div className="flex p-1 bg-muted rounded-lg">
                      <Button 
                        variant={!state.gradient ? "secondary" : "ghost"} 
                        size="sm" 
                        className="h-7 text-xs px-3"
                        onClick={() => updateState({ gradient: false })}
                      >
                        {t.solid}
                      </Button>
                      <Button 
                        variant={state.gradient ? "secondary" : "ghost"} 
                        size="sm" 
                        className="h-7 text-xs px-3"
                        onClick={() => updateState({ gradient: true })}
                      >
                        {t.gradient}
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label className="text-xs opacity-50 uppercase tracking-tighter">{t.color1}</Label>
                        <Popover>
                          <PopoverTrigger render={
                            <button 
                              className="w-full h-12 rounded-xl border-2 border-black/5 dark:border-white/10 shadow-sm flex items-center gap-3 px-3 transition-colors hover:border-primary/50"
                              style={{ backgroundColor: state.color1 }}
                            />
                          }>
                            <span className="text-xs font-mono font-bold invert mix-blend-difference">{state.color1}</span>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-3 p-4 rounded-2xl">
                            <HexColorPicker color={state.color1} onChange={(c) => updateState({ color1: c })} />
                            <div className="mt-4 flex gap-2">
                              <span className="text-zinc-500 font-mono text-sm">#</span>
                              <HexColorInput 
                                color={state.color1} 
                                onChange={(c) => updateState({ color1: c })} 
                                className="w-full bg-zinc-100 dark:bg-zinc-800 rounded px-2 py-1 font-mono text-sm"
                              />
                            </div>
                          </PopoverContent>
                        </Popover>
                      </div>

                      {state.gradient && (
                        <div className="space-y-2">
                          <Label className="text-xs opacity-50 uppercase tracking-tighter">{t.color2}</Label>
                          <Popover>
                            <PopoverTrigger render={
                              <button 
                                className="w-full h-12 rounded-xl border-2 border-black/5 dark:border-white/10 shadow-sm flex items-center gap-3 px-3 transition-colors hover:border-primary/50"
                                style={{ backgroundColor: state.color2 }}
                              />
                            }>
                              <span className="text-xs font-mono font-bold invert mix-blend-difference">{state.color2}</span>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-3 p-4 rounded-2xl">
                              <HexColorPicker color={state.color2} onChange={(c) => updateState({ color2: c })} />
                              <div className="mt-4 flex gap-2">
                                <span className="text-zinc-500 font-mono text-sm">#</span>
                                <HexColorInput 
                                  color={state.color2} 
                                  onChange={(c) => updateState({ color2: c })} 
                                  className="w-full bg-zinc-100 dark:bg-zinc-800 rounded px-2 py-1 font-mono text-sm"
                                />
                              </div>
                            </PopoverContent>
                          </Popover>
                        </div>
                      )}
                    </div>

                    {state.gradient && (
                      <div className="space-y-4 pt-2">
                        <div className="flex justify-between items-baseline mb-2">
                          <Label className="text-sm font-medium opacity-60">{t.angle}</Label>
                          <span className="font-mono text-xs font-bold text-primary">{state.angle}°</span>
                        </div>
                        <Slider 
                          value={[state.angle]} 
                          onValueChange={(v) => updateState({ angle: Array.isArray(v) ? v[0] : v })} 
                          max={360} 
                          step={1} 
                        />
                      </div>
                    )}
                  </div>

                  <div className="space-y-3">
                    <Label className="text-xs opacity-50 uppercase tracking-tighter">{t.presetsPalette}</Label>
                    <div className="grid grid-cols-5 gap-2">
                      {COLOR_PRESETS.map((c) => (
                        <button
                          key={c}
                          className={cn(
                            "w-full aspect-square rounded-full transition-all hover:scale-110 active:scale-95 border-2 border-transparent",
                            state.color1 === c && "border-white ring-2 ring-primary"
                          )}
                          style={{ backgroundColor: c }}
                          onClick={() => updateState({ color1: c })}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </TabsContent>
            </Tabs>

            <div className="mt-auto pt-6 space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <Button variant="outline" onClick={randomize} className="rounded-xl h-12 gap-2" disabled={authLoading}>
                  <Dice5 className="w-4 h-4" /> {t.random}
                </Button>
                <Button 
                  onClick={saveBlob} 
                  className="rounded-xl h-12 gap-2 bg-primary hover:bg-primary/90 text-white" 
                  disabled={saving || authLoading}
                >
                  {saving ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                  {currentUser ? t.save : t.loginToSave}
                </Button>
              </div>
              <DropdownMenu>
                <DropdownMenuTrigger
                  render={
                    <Button className="w-full rounded-xl h-12 gap-2 bg-[#FF006E] hover:bg-[#D4005B] text-white" />
                  }
                >
                  <Download className="w-4 h-4" /> {t.export} <ChevronDown className="w-3 h-3 opacity-50" />
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-[180px] rounded-xl">
                  <DropdownMenuItem onClick={() => downloadFile("svg")} className="gap-2 cursor-pointer font-display">
                    <Plus className="w-4 h-4 rotate-45" /> Download SVG
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => downloadFile("png")} className="gap-2 cursor-pointer font-display">
                    <Palette className="w-4 h-4" /> Download PNG 2x
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => copyToClipboard(fullSvgString, "svg")} className="gap-2 cursor-pointer font-display">
                    <Copy className="w-4 h-4" /> Copy SVG Code
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => copyToClipboard(`clip-path: path('${currentPath}');`, "css")} className="gap-2 cursor-pointer font-display">
                    <Code className="w-4 h-4" /> Copy CSS Clip-path
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>

              <div className="bg-muted/30 border border-white/5 rounded-2xl p-4">
                <p className="text-[10px] font-bold uppercase tracking-wider opacity-40 mb-3">{t.quickPresets}</p>
                <div className="grid grid-cols-3 gap-2">
                  {PRESETS.map((p) => (
                    <button
                      key={p.name}
                      onClick={() => applyPreset(p)}
                      className="px-2 py-1.5 rounded-lg bg-secondary text-secondary-foreground text-[10px] font-bold hover:bg-secondary/80 transition-all active:scale-95 border border-white/5 font-display"
                    >
                      {p.name}
                    </button>
                  ))}
                </div>
              </div>

              <footer className="text-center pt-2">
                <p className="text-[10px] text-zinc-400">
                  {t.inspired} <a href="https://haikei.app" className="underline hover:text-primary">Haikei.app</a> • {t.madeWith} ❤️
                </p>
              </footer>
            </aside>
          </main>
        </div>
      </TooltipProvider>
    );
  }
