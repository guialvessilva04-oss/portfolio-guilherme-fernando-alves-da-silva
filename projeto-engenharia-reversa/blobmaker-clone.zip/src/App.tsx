import { useState, useCallback, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  RefreshCw, 
  Download, 
  Copy, 
  Check, 
  Github, 
  Twitter,
  Layers,
  Maximize2
} from "lucide-react";
import confetti from "canvas-confetti";
import { generateBlobPath } from "@/src/lib/blob";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { 
  Tooltip, 
  TooltipContent, 
  TooltipProvider, 
  TooltipTrigger 
} from "@/components/ui/tooltip";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

const COLORS = [
  "#FF006E", "#8338EC", "#3A86FF", "#FB5607", "#FFBE0B",
  "#06D6A0", "#118AB2", "#073B4C", "#EF476F", "#FFD166"
];

export default function App() {
  const [complexity, setComplexity] = useState(6);
  const [contrast, setContrast] = useState(5);
  const [color, setColor] = useState("#FF006E");
  const [seed, setSeed] = useState(Math.random() * 1000);
  const [copied, setCopied] = useState(false);
  const [path, setPath] = useState("");

  const generateNew = useCallback(() => {
    setSeed(Math.random() * 1000);
  }, []);

  useEffect(() => {
    const newPath = generateBlobPath(400, complexity, contrast, seed);
    setPath(newPath);
  }, [complexity, contrast, seed]);

  const copySvg = async () => {
    const svgString = `<svg viewBox="0 0 400 400" xmlns="http://www.w3.org/2000/svg">
  <path fill="${color}" d="${path}"/>
</svg>`;
    await navigator.clipboard.writeText(svgString);
    setCopied(true);
    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 },
      colors: [color, "#ffffff"]
    });
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadSvg = () => {
    const svgString = `<svg viewBox="0 0 400 400" xmlns="http://www.w3.org/2000/svg">
  <path fill="${color}" d="${path}"/>
</svg>`;
    const blob = new Blob([svgString], { type: "image/svg+xml" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `blob-${Math.floor(seed)}.svg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <TooltipProvider>
      <div className="min-h-screen bg-[#fafafa] text-[#1a1a1a] font-sans selection:bg-primary/20 overflow-hidden">
        {/* Top Banner */}
        <div 
          className="w-full py-3 px-4 text-center text-white font-medium text-sm transition-colors duration-500"
          style={{ backgroundColor: color }}
        >
          <span className="opacity-90">Blobmaker is now a part of </span>
          <a href="https://haikei.app" target="_blank" rel="noreferrer" className="font-bold underline underline-offset-4 hover:opacity-80 transition-opacity">
            Haikei.app
          </a>
          <span className="opacity-90">. Try it out for free!</span>
        </div>

        {/* Header */}
        <header className="absolute top-12 left-0 right-0 p-6 flex justify-between items-center z-50">
          <div className="flex items-center gap-4 group cursor-default">
            <div className="relative w-12 h-12 flex items-center justify-center">
              {/* Orange Blob (Behind) */}
              <svg viewBox="0 0 200 200" className="absolute w-full h-full left-2 -top-1 opacity-90 group-hover:scale-110 transition-transform duration-500" xmlns="http://www.w3.org/2000/svg">
                <path fill="#FB5607" d="M44.7,-76.4C58.1,-69.2,70.1,-59.1,79.6,-46.5C89.1,-33.9,96.1,-18.8,95.7,-3.8C95.3,11.2,87.5,26.1,77.5,39.4C67.5,52.7,55.3,64.4,41.4,72.4C27.5,80.4,11.9,84.7,-3.1,89.1C-18.1,93.5,-32.5,98,-45.4,94.1C-58.3,90.2,-69.7,77.9,-78.3,64.4C-86.9,50.9,-92.7,36.2,-94.1,21.3C-95.5,6.4,-92.5,-8.7,-86.7,-22.6C-80.9,-36.5,-72.3,-49.2,-60.8,-57.1C-49.3,-65,-34.9,-68.1,-21.5,-75.3C-8.1,-82.5,4.3,-93.8,17.9,-93.2C31.5,-92.6,44.7,-76.4Z" transform="translate(100 100)" />
              </svg>
              {/* Pink Blob (Front) */}
              <svg viewBox="0 0 200 200" className="absolute w-full h-full -left-1 bottom-0 group-hover:scale-110 transition-transform duration-500 delay-75" xmlns="http://www.w3.org/2000/svg">
                <path fill="#FF006E" d="M41.5,-70.2C53.4,-63.5,62.5,-51.1,69.4,-37.8C76.3,-24.5,81.1,-10.3,80.1,3.6C79.1,17.5,72.3,31.1,63.4,42.8C54.5,54.5,43.5,64.3,30.8,70.8C18.1,77.3,3.7,80.5,-11.2,79.2C-26.1,77.9,-41.5,72.1,-54.1,62.6C-66.7,53.1,-76.5,39.9,-81.1,25.3C-85.7,10.7,-85.1,-5.3,-80.1,-19.8C-75.1,-34.3,-65.7,-47.3,-53.8,-54C-41.9,-60.7,-27.5,-61.1,-14.1,-67.8C-0.7,-74.5,11.7,-87.5,25.4,-88.2C39.1,-88.9,41.5,-70.2Z" transform="translate(100 100)" />
              </svg>
              <span className="relative z-10 font-black text-3xl text-white select-none group-hover:scale-110 transition-transform duration-500">B</span>
            </div>
            <div className="flex items-baseline gap-2 ml-2">
              <span className="text-2xl font-bold text-[#333] tracking-tight">By</span>
              <span className="text-2xl font-bold text-[#FF006E] tracking-tight">z creative labs</span>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <span className="text-xs font-bold uppercase tracking-widest opacity-40">Share</span>
            <Button variant="ghost" size="icon" asChild className="rounded-full hover:bg-black/5">
              <a href="https://twitter.com" target="_blank" rel="noreferrer">
                <Twitter className="w-5 h-5 fill-current" />
              </a>
            </Button>
          </div>
        </header>

        {/* Main Preview Area */}
        <main className="flex-1 flex flex-col items-center justify-center p-4 min-h-[calc(100vh-180px)]">
          <div className="relative w-full max-w-md aspect-square flex items-center justify-center">
            {/* Background pattern or subtle grid */}
            <div className="absolute inset-0 opacity-[0.03] pointer-events-none" 
                 style={{ backgroundImage: 'radial-gradient(#000 1px, transparent 1px)', backgroundSize: '24px 24px' }} />
            
            {/* Dotted gray square around the object */}
            <div className="absolute inset-0 border-2 border-dotted border-gray-400/10 pointer-events-none" />
            
            <AnimatePresence mode="wait">
              <motion.svg
                key={path}
                viewBox="0 0 400 400"
                className="w-full h-full drop-shadow-2xl"
                initial={{ scale: 0.8, opacity: 0, rotate: -10 }}
                animate={{ scale: 1, opacity: 1, rotate: 0 }}
                exit={{ scale: 1.1, opacity: 0, rotate: 10 }}
                transition={{ type: "spring", stiffness: 200, damping: 20 }}
              >
                <motion.path
                  fill={color}
                  d={path}
                  layoutId="blob-path"
                  transition={{ duration: 0.5, ease: "easeInOut" }}
                />
              </motion.svg>
            </AnimatePresence>
          </div>
        </main>

        {/* Controls Area */}
        <div className="w-full max-w-6xl mx-auto px-4 pb-12 z-50">
          <div className="bg-white/80 backdrop-blur-xl border border-black/5 rounded-xl shadow-2xl p-6 flex flex-col md:flex-row items-center gap-12">
            
            {/* Color Picker (Now on the left) */}
            <div className="flex items-center gap-4 pr-8 border-b md:border-b-0 md:border-r border-black/5 pb-6 md:pb-0 w-full md:w-auto justify-center">
              <Popover>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <PopoverTrigger asChild>
                      <Button 
                        variant="outline" 
                        size="icon" 
                        className="rounded-full w-12 h-12 border-2 transition-all hover:scale-105 active:scale-95 shrink-0"
                        style={{ backgroundColor: color, borderColor: 'rgba(0,0,0,0.05)' }}
                      />
                    </PopoverTrigger>
                  </TooltipTrigger>
                  <TooltipContent>Change Color</TooltipContent>
                </Tooltip>
                <PopoverContent className="w-64 p-4 rounded-2xl shadow-xl border-black/5">
                  <div className="space-y-4">
                    <div className="grid grid-cols-5 gap-2">
                      {COLORS.map((c) => (
                        <button
                          key={c}
                          className={cn(
                            "w-8 h-8 rounded-full transition-all hover:scale-110 active:scale-90",
                            color === c && "ring-2 ring-offset-2 ring-primary"
                          )}
                          style={{ backgroundColor: c }}
                          onClick={() => setColor(c)}
                        />
                      ))}
                    </div>
                    <div className="flex gap-2 items-center">
                      <Input 
                        type="color" 
                        value={color} 
                        onChange={(e) => setColor(e.target.value)}
                        className="w-10 h-10 p-1 rounded-lg cursor-pointer border-none"
                      />
                      <Input 
                        type="text" 
                        value={color} 
                        onChange={(e) => setColor(e.target.value)}
                        className="flex-1 font-mono text-sm uppercase"
                      />
                    </div>
                  </div>
                </PopoverContent>
              </Popover>
              <span className="font-mono text-sm font-bold uppercase tracking-wider opacity-60 select-all">{color}</span>
            </div>

            {/* Complexity & Contrast */}
            <div className="flex flex-1 items-center gap-16 w-full px-8">
              <div className="flex-1 space-y-6">
                <div className="flex justify-between items-center px-1">
                  {/* Triangle with dotted tips */}
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" className="opacity-40">
                    <path d="M12 5l7 14H5l7-14z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                    <circle cx="12" cy="5" r="1.5" fill="currentColor" />
                    <circle cx="19" cy="19" r="1.5" fill="currentColor" />
                    <circle cx="5" cy="19" r="1.5" fill="currentColor" />
                  </svg>
                  {/* Pentagon with dotted tips */}
                  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" className="opacity-40">
                    <path d="M12 3l9 7l-3.5 11h-11l-3.5 -11z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                    <circle cx="12" cy="3" r="1.5" fill="currentColor" />
                    <circle cx="21" cy="10" r="1.5" fill="currentColor" />
                    <circle cx="17.5" cy="21" r="1.5" fill="currentColor" />
                    <circle cx="6.5" cy="21" r="1.5" fill="currentColor" />
                    <circle cx="3" cy="10" r="1.5" fill="currentColor" />
                  </svg>
                </div>
                <Slider 
                  value={[complexity]} 
                  onValueChange={(v) => setComplexity(Array.isArray(v) ? v[0] : v)} 
                  min={3} 
                  max={12} 
                  step={1}
                  className="cursor-pointer"
                  style={{ "--slider-thumb-color": color } as any}
                />
              </div>

              <div className="flex-1 space-y-5">
                <div className="flex justify-between items-center px-1">
                  {/* Circle Icon */}
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="opacity-40">
                    <circle cx="12" cy="12" r="10" />
                  </svg>
                  {/* Melted T Icon */}
                  <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor" className="opacity-40">
                    <path d="M8,4 C10,3 13,3 14,4 C15,5 14,7 15,9 C16,11 20,10 21,12 C22,14 20,17 18,18 C16,19 13,17 11,18 C9,19 7,22 5,21 C3,20 2,17 3,14 C4,11 3,8 4,6 C5,4 6,5 8,4 Z" />
                  </svg>
                </div>
                <Slider 
                  value={[contrast]} 
                  onValueChange={(v) => setContrast(Array.isArray(v) ? v[0] : v)} 
                  min={0} 
                  max={10} 
                  step={1}
                  className="cursor-pointer"
                  style={{ "--slider-thumb-color": color } as any}
                />
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-4 border-t md:border-t-0 md:border-l border-black/5 pt-6 md:pt-0 md:pl-8 w-full md:w-auto justify-center">
              <div className="h-10 w-[1px] bg-black/5 mx-1 hidden md:block" />

              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    onClick={downloadSvg}
                    className="rounded-full w-14 h-14 hover:bg-black/5 transition-all active:scale-90"
                    style={{ color }}
                  >
                    <Download className="w-6 h-6" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Download SVG</TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    onClick={copySvg}
                    className="rounded-full w-14 h-14 hover:bg-black/5 transition-all active:scale-90"
                    style={{ color }}
                  >
                    {copied ? <Check className="w-6 h-6 text-green-500" /> : <Copy className="w-6 h-6" />}
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Copy SVG</TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    onClick={generateNew}
                    className="rounded-full w-14 h-14 hover:bg-black/5 transition-all active:scale-90"
                    style={{ color }}
                  >
                    <Maximize2 className="w-6 h-6" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Randomize Shape</TooltipContent>
              </Tooltip>
            </div>
          </div>
          
          <p className="text-center mt-4 text-[10px] uppercase tracking-[0.2em] font-bold opacity-30 pointer-events-none">
            Made with love for creative developers
          </p>
        </div>
      </div>
    </TooltipProvider>
  );
}
