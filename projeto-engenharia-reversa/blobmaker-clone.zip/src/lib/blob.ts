/**
 * Generates a smooth SVG path for a blob.
 * @param size The size of the square bounding box.
 * @param growth The complexity (number of points).
 * @param edge The contrast (randomness of point distance from center).
 * @param seed Random seed for reproducibility.
 */
export function generateBlobPath(
  size: number,
  growth: number,
  edge: number,
  seed: number
): string {
  const center = size / 2;
  const radius = size / 3;
  const points: { x: number; y: number }[] = [];
  const numPoints = Math.max(3, Math.floor(growth));
  
  // Simple LCG for deterministic randomness based on seed
  const random = (s: number) => {
    const x = Math.sin(s) * 10000;
    return x - Math.floor(x);
  };

  for (let i = 0; i < numPoints; i++) {
    const angle = (i / numPoints) * Math.PI * 2;
    const offset = (random(seed + i) - 0.5) * edge * (radius / 10);
    const r = radius + offset;
    points.push({
      x: center + r * Math.cos(angle),
      y: center + r * Math.sin(angle),
    });
  }

  return createSmoothPath(points);
}

function createSmoothPath(points: { x: number; y: number }[]): string {
  if (points.length < 3) return "";

  const n = points.length;
  let path = `M ${points[0].x} ${points[0].y}`;

  for (let i = 0; i < n; i++) {
    const p0 = points[i === 0 ? n - 1 : i - 1];
    const p1 = points[i];
    const p2 = points[(i + 1) % n];
    const p3 = points[(i + 2) % n];

    // Catmull-Rom to Cubic Bezier conversion
    // cp1 = p1 + (p2 - p0) / 6
    // cp2 = p2 - (p3 - p1) / 6
    
    const cp1x = p1.x + (p2.x - p0.x) / 6;
    const cp1y = p1.y + (p2.y - p0.y) / 6;
    
    const cp2x = p2.x - (p3.x - p1.x) / 6;
    const cp2y = p2.y - (p3.y - p1.y) / 6;

    path += ` C ${cp1x} ${cp1y}, ${cp2x} ${cp2y}, ${p2.x} ${p2.y}`;
  }

  path += " Z";
  return path;
}
